import 'main.dart';
void main() {
  int age = 20;
  String genre = "femme";
  String resultat = estMajeur(age, genre);
  print("La personne est $resultat.");
}
