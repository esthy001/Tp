
String estMajeur(int age, String genre) {
  if (age < 18) {
    if (genre == "homme") {
      return "un mineur";
    } else {
      return "une mineure";
    }
  } else {
    if (genre == "homme") {
      return "un majeur";
    } else {
      return "une majeure";
    }
  }
}
