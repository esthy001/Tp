int factorielle(int n) {
  if (n < 0) {
    throw ArgumentError("La factorielle n'est pas définie pour les nombres négatifs.");
  } else if (n == 0) {
    return 1;
  } else {
    int resultat = 1;
    for (int i = 1; i <= n; i++) {
      resultat *= i;
    }
    return resultat;
  }
}
