import 'main.dart';
void main() {
  int nombre = 5;
  int resultat = factorielle(nombre);
  print("La factorielle de $nombre est $resultat.");
}
