import 'main.dart';
void main() {
  int nombreDeFois = 3;
  afficherBonjour(nombreDeFois);
}
