
void afficherBonjour(int nombreDeFois) {
  for (int i = 0; i < nombreDeFois; i++) {
    print("Bonjour le monde");
  }
}
