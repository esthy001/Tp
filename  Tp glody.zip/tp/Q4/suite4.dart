import 'main.dart';
void main() {
  List<int> nombres = [2, 4, 6, 8, 10];
  double resultat = moyenne(nombres);
  print("La moyenne des nombres est $resultat.");
}
