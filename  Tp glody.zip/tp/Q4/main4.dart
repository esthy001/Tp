double moyenne(List<int> nombres) {
  double somme = 0;
  for (int nombre in nombres) {
    somme += nombre;
  }
  return somme / nombres.length;
}
