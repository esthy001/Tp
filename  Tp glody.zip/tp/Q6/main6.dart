class Etudiant {
  int _id;
  String _nom;
  String _postnom;
  String _prenom;
  String _sexe;
  int _age;
  DateTime _dateNaissance;
  double _poids;
  double _taille;

  Etudiant(this._id, this._nom, this._postnom, this._prenom, this._sexe, this._age, this._dateNaissance, this._poids, this._taille);

  int get id => _id;
  set id(int value) => _id = value;

  String get nom => _nom;
  set nom(String value) => _nom = value;

  String get postnom => _postnom;
  set postnom(String value) => _postnom = value;

  String get prenom => _prenom;
  set prenom(String value) => _prenom = value;

  String get sexe => _sexe;
  set sexe(String value) => _sexe = value;

  int get age => _age;
  set age(int value) => _age = value;

  DateTime get dateNaissance => _dateNaissance;
  set dateNaissance(DateTime value) => _dateNaissance = value;

  double get poids => _poids;
  set poids(double value) => _poids = value;

  double get taille => _taille;
  set taille(double value) => _taille = value;

  void afficher() {
    print("Id: $_id");
    print("Nom: $_nom");
    print("Postnom: $_postnom");
    print("Prenom: $_prenom");
    print("Sexe: $_sexe");
    print("Age: $_age");
    print("Date de naissance: $_dateNaissance");
    print("Poids: $_poids");
    print("Taille: $_taille");
  }
}
