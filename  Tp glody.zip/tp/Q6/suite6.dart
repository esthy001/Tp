import 'main.dart';
void main() {
  Etudiant etudiant =  Etudiant (1, "Doe", "Smith", "John", "homme", 20, DateTime(2002, 1, 1), 70.0, 1.8);
  etudiant.afficher();
}
