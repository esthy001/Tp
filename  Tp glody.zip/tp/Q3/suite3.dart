
import 'main.dart';
void main() {
  double a = 1;
  double b = -5;
  double c = 6;
  List<double> solutions = solutionsEquationSecondDegre(a, b, c);
  if (solutions.isEmpty) {
    print("L'équation n'a pas de solution réelle.");
  } else if (solutions.length == 1) {
    print("L'équation a une solution réelle: ${solutions[0]}");
  } else {
    print("L'équation a deux solutions réelles: ${solutions[0]} et ${solutions[1]}");
  }
}
